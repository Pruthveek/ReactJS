const Footer = () => {
    return (
        <div className="footer">
            <h1>FOOD MARKET <sup>&#169;</sup> since 2002.</h1>
        </div>
    );
  };
  export default Footer;